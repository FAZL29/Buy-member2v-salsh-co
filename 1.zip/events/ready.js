module.exports = {
  name: 'ready',
  once: true,
  execute(client) {
    client.user.setPresence({
      status: 'idle',
      activities: [{ name: 'working !', type: 'PLAYING' }]
    });

    console.log(`${client.user.username} Is Online !`);
  },
};