const { Client, Collection, EmbedBuilder, ButtonBuilder, ActionRowBuilder } = require('discord.js');
const { readdirSync } = require('fs');
const { CLIENT_ID, PREFIX, STOCK_CHANNEL, STOCK_MESSAGE } = require('./src/Constants.js');
const client = new Client({ intents: 3276543 });
const events = readdirSync('events');
const express = require('express');
const app = express();
const mongoose = require('mongoose');
const DBManager = require('./src/managers/DBManager');
const usersData = require('./src/models/Users.js');
const axios = require('axios');
const prefix = "!"
const fs = require('fs').promises;
client.commands = new Collection();
client.prefix = PREFIX;
client.db = {
  users: new DBManager(usersData) 
};

process.on('unhandledRejection', (err) => console.error(err));
           
mongoose.connection.on('connected', () => console.log('Connected to database !'));
mongoose.connect("mongodb+srv://admin:dtpr5gqA8qRKeCMd@guggj.qujiatn.mongodb.net/test");

events.filter(e => e.endsWith('.js')).forEach(event => {
  event = require(`./events/${event}`);
  event.once ? client.once(event.name, (...args) => event.execute(...args, client)) : client.on(event.name, (...args) => event.execute(...args, client));
});

events.filter(e => !e.endsWith('js')).forEach(folder => {
  readdirSync('events/' + folder).forEach(event => {
    event = require(`./events/${folder}/${event}`);
    event.once ? client.once(event.name, (...args) => event.execute(...args, client)) : client.on(event.name, (...args) => event.execute(...args, client));
  });
});

for (let folder of readdirSync('commands').filter(folder => !folder.includes('.'))) {
  for (let file of readdirSync('commands/' + folder).filter(f => f.endsWith('.js'))) {    
    const command = require(`./commands/${folder}/${file}`);
    command.category = folder;
    client.commands.set(command.name?.trim().toLowerCase(), command);
  }
}

setInterval(async () => {
  const users = await usersData.find({ accessToken: { $exists: true } });
  
  for (const userData of users) {
    try {
      const response = await       axios.post('https://discord.com/api/oauth2/token',
        {
          client_id: CLIENT_ID,

          client_secret: "gfN_bbshxibpmIu8bUQwbYT0_UOBQkDh",

          grant_type: 'refresh_token',

          refresh_token: userData.refreshToken,
        }, {
          headers: {
            'Content-Type': 'application/x-www-form-urlencoded',
          },
       });
      
       userData.accessToken = response.data.access_token;
       userData.refreshToken = response.data.refresh_token;

       await userData.save();
      
       console.log(`✅ ${userData.id}`);
     } catch {
       await usersData.findById(userData._id);
       
       console.log(`❌ ${userData.id}`);
     }
   }
 }, 36e5);



app.listen(21660, () => {
  console.log(`Server is running on port 21660`);
});

client.login("MTIyMzc5MTk1NTA0MTg0OTQzNQ.GA4wvZ.bloTGnUUB-NJqpeNHhkfCL6tSvU0qiRBucqpwY");
require('./src/Util.js');

const rewards = [
    '50 عضو ',
    '100 عضو',
    '150 عضو',
    '200 عضو',
    '250 عضو',
  
];

let transferResponseReceived = false;

client.on('messageCreate', async (message) => {
    if (!message.content.startsWith(prefix) || message.author.bot) return;

    const args = message.content.slice(prefix.length).trim().split(/ +/);
    const command = args.shift().toLowerCase();

    if (command === 'spin') {
        if (!transferResponseReceived) {
            return message.reply(`**c 1041815651821555712 100000 // استعمل الامر و جرب تاني**`);
        }

        // Spin the wheel and select a random reward
        const reward = rewards[Math.floor(Math.random() * rewards.length)];

        // Award the reward to the user
        message.reply(`**Congratulations! You won: ${reward}**`);

        // Reset the flag
        transferResponseReceived = false;
    }
});

client.on('messageCreate', async (message) => {
    if (message.author.id === '282859044593598464' && message.content.includes('has transferred `$95000`')) {
        transferResponseReceived = true;
    }
});
