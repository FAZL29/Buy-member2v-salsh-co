const { ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');
module.exports = {
  name: 'token',
  execute(message, args, client) {
    message.channel.send(`https://media.discordapp.net/attachments/1151956242760212500/1162042586966528000/lv_0_20231012175825.mp4?ex=653a7f7e&is=65280a7e&hm=8ebc9dc9129716a8eb92a8aaff4dec4f41fa2bf065c4d1caa3a5c9c878fef6c2&`);
  },
};