const ms = require('ms');
const cooldowns = new Map();

module.exports = {
  name: 'boost',
  async execute(message, args, client) {
    const userId = message.author.id;
    const user = client.users.cache.get(userId);

    if (cooldowns.has(userId)) {
      const expirationTime = cooldowns.get(userId);
      const remainingTime = expirationTime - Date.now();

      if (remainingTime > 0) {
        const remainingTimeString = ms(remainingTime);
        return message.lineReplyNoMention(`يرجى استعمال هاذا الأمر في الأسبوع الثاني. <:emoji_1:1221501568902365225>`);
      }
    }

    const cooldownTime = ms('7d');
    const requiredRoleName = 'Booster';

    const member = message.guild.members.cache.get(userId);

    if (!member || !member.roles.cache.some(role => role.name === requiredRoleName)) {
      return message.lineReplyNoMention(`**لم تعمل بوست للسيرفر <:emoji_1:1221501568902365225>!**`);
    }

    const userData = await client.db.users.patch(user.id);

    userData.boostCount = (userData.boostCount || 0) + 1;
    const boostAmount = userData.boostCount % 1 === 2 ? 100 : 50;

    cooldowns.set(userId, Date.now() + cooldownTime);

    userData.balance += boostAmount;
    userData.lastBoostTime = new Date().toISOString();
    await userData.save();

    message.channel.send(`**تم اضافة ${boostAmount} كوينز الى حسابك بنجاج <:emoji_1:1221501568902365225>!**`);
  },
};