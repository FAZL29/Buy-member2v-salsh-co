const { EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js'); 

module.exports = {
  name: 'help',
  async execute(message, args, client) {
    const row = new ActionRowBuilder().addComponents(
      new ButtonBuilder() 
        .setStyle(ButtonStyle.Secondary)
        .setCustomId('1')
        .setEmoji('<:rules:1200119375177457807>')
        .setLabel('Public'), 
      new ButtonBuilder() 
        .setStyle(ButtonStyle.Secondary)
        .setCustomId('2')
        .setEmoji('<:rules:1200119375177457807>')
        .setLabel('Reseller'),
      new ButtonBuilder() 
        .setStyle(ButtonStyle.Secondary)
        .setCustomId('3')
        .setEmoji('<:rules:1200119375177457807>')
        .setLabel('Owner'),
       new ButtonBuilder()    
    .setStyle(ButtonStyle.Secondary) 
  
        .setCustomId('4')   
        .setEmoji('<:rules:1200119375177457807>') 
       .setLabel('dev'),
      new ButtonBuilder()    
          .setStyle(ButtonStyle.Secondary)   
    
    .setCustomId('5')
        .setEmoji('<:rules:1200119375177457807>') 
        .setLabel('how-to-buy'),
    
    );

    const msg = await message.channel.send({ embeds: [], components: [row] });

    // الاستجابة عند النقر على الأزرار
    const filter = (interaction) => interaction.isButton();
    const collector = msg.createMessageComponentCollector({ filter, time: 300000000 });

    collector.on('collect', async (interaction) => {
      const userId = interaction.user.id;
      const buttonId = interaction.customId;

      let replyContent = '';
      switch (buttonId) {
        case '1':
          replyContent = `**!stock** لمعرفة ستوك الأعضاء المتواجد في المخزون
**!coins** لمعرفت رصيدك الحالي
**!boost** لاستلام هدية البوست
**!top** اعلى 6 اشخاص يمتلكون كوينز
**!T** لكي تعتي ل احد كويناتك`;
          break;
        case '2':
          if (interaction.member.roles.cache.some(role => role.name === 'new role')) {
            replyContent = 'يتم العمل على هاذا في اقرب وقت ممكن';
          } else {
            replyContent = 'لا تمتلك الصلاحيات الكافية لاستعمال هاذا الزر';
          }
          break;
        case '3':
          if (interaction.member.roles.cache.some(role => role.name === 'new role')) {
            replyContent = `**!give [user] [amount]** لاضافة كوينز للعضو
**!take [user] [amount] لسحب كوينز من العضو
!bank [bank id] لوضع ايدي البنك الجديد
!limite [limite members] لوضع اقل عدد للأعضاء من الشراء
!clinet [role id] لوضع رول الشراء
!stock update [img link] لوضع صورة للستوك
!panel img [img link] لوضع صورة للبانل و ايضا يمكنك تركها بدون صورة
!join [serverid] [amount] لادخال اعضاء للسيرفر
!check [user] لفحص اذا الشخص موثق نفسه او لا
!send لبعث زر وثق نفسك
!panel بعث لوحة شراء أعضاء
!log لوضع ايدي روم تمت العملية
!price لوضع سعر الأعضاء
!set name [name] لوضع اسم للبوت
!set avatar [avatar link] لتغيير صورة البوت
!servers يعطيك كم من سيرفر موجود فيه البوت
!servers-id يعطيك ايديات السيرفارات
!box [amount] لكي تضع بوكس في
الروم
!states لكي تحط ستاتس للبوت مثل يلعب و كذا
!nitro لكي تبعت نيترو فيك في الروم عل شكل اثبت نفسك
!bio لكي تضع بايو للبوت
!basic لكي تبعت نيترو بيسك فيك في الروم عل شكل اثبت نفسك
!send-b-panel لكي تبعت لوحه تحكم خاصه بلرصيد
!send-m-panel لكي تبعت لوحه التحكم الخاصه بلاعضاء
!mozaa [role id] لتحديد رول الموزع
!mozaaDis [amount] تحديد سعر الموزع**`;
          }
  
              break;
        case '4':
          if (interaction.member.roles.cache.some(role => role.name === 'Member')) {
            replyContent = `**Hell
Marwan
Adham**`           
} 
      
             break;
        case '5':
          if  (interaction.member.roles.cache.some(role => role.name === 'Member')) {
            replyContent =  `**اول شي عليك ان تفعله ان تشتري كوينز من شراء رصيد بعد م تحول بيجيلك الكوينز تقدر تكتب !coins عشان تشوف كويناتك كم بعده تدخل البوت سيرفرك بعده تدوس شراء اعضاء و مبروك عليك الاعضاء**`   
       
            } else {
            replyContent = 'لا تمتلك الصلاحيات الكافية لاستعمال هاذا الزر';
          }
          break;
        default:
          replyContent = 'نص الرد الافتراضي إذا لم يتم التعرف على الزر';
      }
      await interaction.reply({ content: replyContent, ephemeral: true });
    });

    collector.on('end', (collected, reason) => {
      if (reason === 'time') {
        msg.edit({ components: [row] }); 
      }
    });
  },
};