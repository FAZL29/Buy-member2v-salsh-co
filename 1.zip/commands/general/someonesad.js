module.exports = {

    name: 'someonesad',

    description: 'If someone feels sad, use this command to make them happy.',

    execute(message, args) {

        const user = message.mentions.users.first();

        if (!user) {

            return message.reply('Please mention a user to make them happy.');

        }

        message.channel.send('انشاء الله هتكون فرحان بعد الفيديو دا بيو بيو 😂 😂');

    },

};

