const { EmbedBuilder } = require('discord.js');

const usersData = require('../../src/models/Users.js');

module.exports = {

    name: 'T',

    description: 'Transfer coins to another user.',

    async execute(message, args) {

        const recipient = message.mentions.users.first();

        const amount = parseInt(args[1]);

        // Check if recipient is mentioned

        if (!recipient) {

            return message.reply('Please mention a user to transfer coins to.');

        }

        // Check if amount is valid

        if (isNaN(amount) || amount <= 0) {

            return message.reply('Please provide a valid positive number for the amount.');

        }

        // Fetch sender's data

        const senderData = await usersData.findOne({ id: message.author.id });

        if (!senderData || senderData.balance < amount) {

            return message.reply('You don\'t have enough coins to transfer.');

        }

        // Update sender's balance

        senderData.balance -= amount;

        await senderData.save();

        // Fetch recipient's data

        let recipientData = await usersData.findOne({ id: recipient.id });

        if (!recipientData) {

            recipientData = new usersData({ id: recipient.id, balance: 0 });

        }

        // Update recipient's balance

        recipientData.balance += amount;

        await recipientData.save();

        // Build the transfer message

        const transferMessage = `:moneybag: | ${message.author}, has transferred \`${amount}\` to ${recipient}`;

        // Send the transfer message

        message.channel.send(transferMessage);

    },

};

