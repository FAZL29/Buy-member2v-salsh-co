const { EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js'); 
const usersData = require('../../src/models/Users.js');

let stockImage = "https://cdn.discordapp.com/attachments/1220152653951270984/1221497780259000420/20240324_110604.jpg?ex=6612cb75&is=66005675&hm=6a02ab3ba1fa8fe9f7e303a6cfe69ce6c950854d303ded7a26206b742d94095c&";

module.exports = {
  name: 'stock',
  async execute(message, args, client) {
    if (args[0] === 'update') {
      if (args[1]) {
        stockImage = args[1];
        return message.reply(`تم تغيير صورة الستوك بنجاح .`);
      } else {
        return message.reply('يجب تقديم رابط الصورة.');
      }
    }

    let usersCount = await usersData.countDocuments({ accessToken: { $exists: true } });

    const row = new ActionRowBuilder().addComponents(
      new ButtonBuilder()
        .setStyle(ButtonStyle.Secondary)
     .setCustomId('refresh-stock')
                .setLabel('تحديث الستوك')
                .setStyle('Secondary')
                .setEmoji('🔄') 
    );

    const embed = new EmbedBuilder()
      .setColor('Red')
      .setImage(stockImage)
          .setTitle(`يتواجد حاليا : **${usersCount}**`)
      .setTimestamp();

    const msg = await message.channel.send({ embeds: [embed], components: [row] });

    const filter = (interaction) => interaction.isButton();
    const collector = msg.createMessageComponentCollector({ filter, time: 30000000000000000000000000 });

    collector.on('collect', async (interaction) => {
      if (interaction.customId === 'refresh-stock') {
        usersCount = await usersData.countDocuments({ accessToken: { $exists: true } });
        const updatedEmbed = new EmbedBuilder()
          .setColor('Red')
          .setImage(stockImage)
          .setTitle(`يتواجد حاليا : **${usersCount}**`)
          .setTimestamp();
        await interaction.update({ embeds: [updatedEmbed] });
      }
    });

    collector.on('end', (collected, reason) => {
      if (reason === 'time') {
        msg.edit({ components: [row] }); // إزالة الأزرار بعد انقضاء الوقت
      }
    });
  },
};
