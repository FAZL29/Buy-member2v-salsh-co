const { EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js'); 

const usersData = require('../../src/models/Users.js');

module.exports = {

  name: 'coins',

  async execute(message, args, client) {

    const user = args[0] ? client.users.cache.get(args[0]?.toId()) : message.author;

    if (!user) return message.lineReplyNoMention('❌ **هذا المستخدم غير موجود!**');

    if (user.bot) return message.lineReplyNoMention('❌ **البوتات لا تملك ارصدة!**');

    const userData = await usersData.findOne({ id: user.id }) || new usersData({ id: user.id });

    if (userData.balance === 0) {

      return message.lineReplyNoMention('لا تمتلك اي كوينز .');

    }

    const row = new ActionRowBuilder().addComponents(

      new ButtonBuilder()

        .setStyle(ButtonStyle.Secondary)

        .setCustomId('buy-balance')

        .setLabel('شحن رصيد'),

      new ButtonBuilder()

        .setStyle(ButtonStyle.Secondary)

        .setCustomId('withdraw-m-balance')

        .setLabel('شراء اعضاء')

    );

    const embed = new EmbedBuilder()

      .setTitle(`${user.username}'s Profile`)

      .setDescription(`Balance: ${userData.balance} coins`)

      .setImage(user.displayAvatarURL());

    message.reply({ embeds: [embed], components: [row] });

  },

};

