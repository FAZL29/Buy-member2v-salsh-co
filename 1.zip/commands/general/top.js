const { ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js'); 

const usersData = require('../../src/models/Users.js');

module.exports = {

  name: 'top',

  async execute(message, args, client) {

    const topUsers = await usersData.find().sort({ balance: -1 }).limit(6);

    const buttons = await Promise.all(topUsers.map(async (user, index) => {

      const fetchedUser = await client.users.fetch(user.id, false);

           return new ButtonBuilder()

        .setStyle(ButtonStyle.Secondary)

        .setCustomId(`user_${user.id}`)

        .setLabel(`${index + 1}. ${fetchedUser.username}`);

    }));

    const rows = [];

    while (buttons.length > 0) {

      rows.push(new ActionRowBuilder().addComponents(buttons.splice(0, 5)));

    }

    message.reply({ content: 'أعلى 6 مستخدمين بحسب الكوينز:', components: rows });

  },

};