const { EmbedBuilder } = require('discord.js');

module.exports = {

    name: 'come',

    description: 'Send a direct message to a member and invite them to a room.',

    async execute(message, args) {

        // Check if a user mentioned is provided

        const user = message.mentions.users.first();

        if (!user) {

            return message.reply('Please specify a valid user.');

        }

        try {

            // Send a direct message to the user

            await user.send(`**come the staffs want you ${message.channel}**`);

            // Confirmation message in the channel

            await message.channel.send(`**Message has been sent successfully.** <a:PrimeBotVerified:1222192014095945759>`);

        } catch (error) {

            console.error('Error sending message:', error);

            message.reply('There was an error sending the message to ' + user.tag + '. ❌');

        }

    },

};

