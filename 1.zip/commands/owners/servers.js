module.exports = {
  name: 'servers',
  owners: true,
  description: 'Display the number of servers the bot is in',
  execute(message, args, client) {
    const serversCount = client.guilds.cache.size;
    message.channel.send(`The bot is currently in ${serversCount} servers.`);
  },
};