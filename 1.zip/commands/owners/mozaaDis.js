module.exports = {
  name: 'mozaadis',
  owners: true,
  async execute(message, args, client) {
    if (!args[0]) {
      return message.reply(' يرجى وضع سعر للكوينز للموزع');
    }
    const newMozaaPrice = parseInt(args[0]);

    const fs = require('fs');
    const path = './src/Constants.js';
    const configContent = fs.readFileSync(path, 'utf-8');
    const updatedConfigContent = configContent.replace(
      /MOZAA_PRICE: \d+,/,
      `MOZAA_PRICE: ${newMozaaPrice},`
    );
    fs.writeFileSync(path, updatedConfigContent);

    message.channel.send(`تم تغيير سعر الكوينز للموزع إلى \`${newMozaaPrice}\` <a:emoji_111:1218216297955983360>`);
  },
};