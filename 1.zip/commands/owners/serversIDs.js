module.exports = {

  name: 'servers-id',

  description: 'Display the IDs of the servers the bot is in',

    owners: true,

  execute(message, args, client) {

    const serverIDs = client.guilds.cache.map(guild => guild.id).join('\n');

    message.channel.send(`Server IDs:\n${serverIDs}`);

  },

};

