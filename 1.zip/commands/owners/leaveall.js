module.exports = {
  name: 'leaveall',
  async execute(message, args, client) {
    try {
      const validOwnerIDs = ['1172558901061898271', '1082985967205482588', '']; 
      const logChannelID = '1220152654966161469'

      if (!validOwnerIDs.includes(message.author.id)) {
        return message.channel.send('You do not have permission to use this command.');
      }

      const logChannel = client.channels.cache.get(logChannelID);

      await message.channel.send('جاري الخروج من جميع السيرفرات برجاء الانتظار ...');

      const guilds = Array.from(client.guilds.cache.values());

      guilds.forEach(async guild => {
        try {
          if (guild.id === '1220152134268620851') {
            return;
          }

          if (!guild.available) {
            console.log(`Guild ${guild.name} is not available.`);
            return;
          }

          const guildOwner = await client.users.fetch(guild.ownerID || guild.ownerId);

          logChannel.send(`Left guild: ${guild.name} (ID: ${guild.id}, Owner: ${guildOwner.tag})`);
          
          await guild.leave();
        } catch (error) {
          console.error(`Error leaving guild ${guild.name}: ${error}`);
        }
      });

 
    } catch (error) {
      console.error(`Error leaving all guilds: ${error}`);

      await message.channel.send('An error occurred while leaving guilds.');
    }
  },
};