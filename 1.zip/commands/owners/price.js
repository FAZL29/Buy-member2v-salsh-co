module.exports = {

  name: 'price',

  owners: true,

  async execute(message, args, client) {

    if (!args[0]) {

      return message.reply('يرجى وضع سعر الكوينز الصحيح.');

    }

    const newBALANCE_PRICE = args[0];

    const fs = require('fs');

    const path = './src/Constants.js';

    const configContent = fs.readFileSync(path, 'utf-8');

    

    const updatedConfigContent = configContent.replace(

      /BALANCE_PRICE: \d+,/,

      `BALANCE_PRICE: ${newBALANCE_PRICE},`

    );

    

    fs.writeFileSync(path, updatedConfigContent);

    message.channel.send(`\`\`\`javascript\n${updatedConfigContent}\n\`\`\``);

    const emoji = `<:A4M_setting:1203242437921869864>`;

    message.react(emoji);

  },

};