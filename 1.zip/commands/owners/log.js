module.exports = {
  name: 'balance-log',
  owners: true,
  async execute(message, args, client) {
    if (!args[0]) {
      return message.reply('يرجى وضع ايدي روم الوق');
    }
    const newLogChannelId = args[0];

    const fs = require('fs');
    const path = './src/Constants.js';
    const configContent = fs.readFileSync(path, 'utf-8');

    const updatedConfigContent = configContent.replace(
      /BALANCE_LOG: '(.*)',/,
      `BALANCE_LOG: '${newLogChannelId}',`
    );

    const updatedConfigContentWithDoneChannel = updatedConfigContent.replace(
      /DONE_CHANNEL: '(.*)',/,
      `DONE_CHANNEL: '${newLogChannelId}',`
    );

    fs.writeFileSync(path, updatedConfigContentWithDoneChannel);

    message.channel.send(`تم تغيير روم الوق الى \`${newLogChannelId}\` <:A4M_setting:1203242437921869864>`);
  },
};