const { EmbedBuilder, ActionRowBuilder, ButtonBuilder } = require('discord.js');

module.exports = {

  name: 'invite',
    
    owners: true, 

  description: 'Get the invite link for the verification bot.',

  execute(message, args) {

    // Replace 'YOUR_CLIENT_ID' with your bot's client ID

    const clientId = '1213581772340592641';

    // Generate the invite link

    const inviteLink = `https://discord.com/oauth2/authorize?client_id=1213581772340592641&permissions=68608&scope=bot`;

    // Create a button component

    const button = new ButtonBuilder()

      .setLabel('Invite Bot')

      .setStyle('Link') // This makes the button a hyperlink

      .setURL(inviteLink);

    // Create an action row to hold the button

    const row = new ActionRowBuilder().addComponents(button);

    // Create an embed

    const embed = new EmbedBuilder()

      .setColor('#0099ff')

      .setTitle('Invite Verification Bot')

      .setDescription('Click the button below to invite the verification bot to your server.');

    // Send the embed with the button

    message.channel.send({ embeds: [embed], components: [row] });
      
      
      
      message.delete();

  },

};

