const { EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js'); 

const { BOT_URL } = require('../../src/Constants.js');

module.exports = {

  name: 'send-m-panel',

  owners: true,

  execute(message, args, client) {

    const embed = new EmbedBuilder()

      .setTitle('شراء أعضاء')

      .setColor('#001fff') 

      .setDescription('**يمكنك شراء أعضاء عن طريق الضغط على الزر**')

      .setImage('https://cdn.discordapp.com/attachments/1220152653951270984/1221497779965137060/20240324_110551.jpg?ex=6612cb75&is=66005675&hm=6ecf7f2215900bbb3dd6d8f00c9cb4088dc17cdba8717a77040378082949caf8&')  

      .setTimestamp();

    

    const row = new ActionRowBuilder().addComponents(

      new ButtonBuilder() 

        .setStyle(ButtonStyle.Secondary)

        .setCustomId('withdraw-m-balance')

        .setEmoji('<:cs_members:1172337595057963019>')

        .setLabel('شراء أعضاء'), 

      new ButtonBuilder() 

        .setStyle(ButtonStyle.Link)

        .setURL(BOT_URL)

        .setEmoji('<:robot:1187148708396154952>') 

        .setLabel('إدخال البوت'));

        

    message.channel.send({ embeds: [embed], components: [row] });

    message.delete();

  },

};

