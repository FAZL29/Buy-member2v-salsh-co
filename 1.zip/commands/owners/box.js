const { ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');

let boxLimit = 100;

module.exports = {
  name: 'box',
  owners: true,
  async execute(message, args, client) {
    const subCommand = args[0].toLowerCase();

    if (subCommand === 'limit') {
      const newLimit = +args[1];

      if (!newLimit || isNaN(newLimit) || newLimit <= 0) {
        return message.channel.send('**يرجى تحديد حد صحيح وإيجابي للصندوق!**');
      }

      boxLimit = newLimit;
      return message.channel.send(`**تم تعيين حد الصندوق الجديد إلى ${newLimit} كوين.**`);
    }
    const amount = +subCommand;

    if (!amount || isNaN(amount) || amount <= 0 || amount > boxLimit) {
      return message.channel.send(`**يرجى تحديد عدد صحيح وإيجابي للكوينز (أقل من أو يساوي ${boxLimit})!**`);
    }

    const row = new ActionRowBuilder().addComponents(
      new ButtonBuilder()
        .setCustomId('claimCoins')
        .setLabel('claim .')
        .setEmoji('<:emoji_35:1200340032456761404>')
        .setStyle(ButtonStyle.Secondary)
    );

    const sentMessage = await message.channel.send({
      content: `تم وضع بوكس والذي يقدم لك ${amount} كوين. اضغط على الزر للاستلام <:emoji_1:1221501568902365225>`,
      components: [row],
    });

    const collector = sentMessage.createMessageComponentCollector();

    collector.on('collect', async (interaction) => {
      const userData = await client.db.users.patch(interaction.user.id);
      userData.balance += amount;
      await userData.save();

      sentMessage.edit({
        content: `لقد قام <@${interaction.user.id}> بالضغط على الزر واستلم ${amount} كوين بفضل البوكس <:emoji_1:1221501568902365225> .`,
        components: []
      });

      interaction.user.send(`لقد قمت باستلام ${amount} من البوكس. <:emoji_1:1221501568902365225>`);
      collector.stop();
    });
  },
};