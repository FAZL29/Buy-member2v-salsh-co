module.exports = {

  name: 'give',

  owners: true,

  async execute(message, args, client) {

    const userId = args[0]?.toId();

    const amount = +args[1];

    

    if (!userId) return message.lineReplyNoMention('❌ **يرجى تحديد المستخدم!**');

    if (!amount || isNaN(amount)) return message.lineReplyNoMention('❌ **يرجي تحديد العدد صحيحًا!**');

  

    const user = client.users.cache.get(userId);

    if (!user) return message.lineReplyNoMention('❌ **لا يمكنني العثور على هذا المستخدم!**');

    if (user.bot) return message.lineReplyNoMention('❌ **لا يمكن الإضافة إلى البوتات!**');

  

    const userData = await client.db.users.patch(user.id);

       

    userData.balance += amount;

    await userData.save();

  

    message.channel.send({

      content: `**تم اضافة رصيد ل ${user}, والذي قمت باضافة اليه \`${amount}\` كوينز

اصبح رصيده الحالي \`${userData.balance}\` كوينز**`,

      files: [user.displayAvatarURL({ format: 'png', dynamic: true, size: 1024 })]

    });

  },

};

