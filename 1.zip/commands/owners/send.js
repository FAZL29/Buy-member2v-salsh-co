const { ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');
const { AUTH_URL } = require('../../src/Constants.js');

module.exports = {
  name: 'send',
  owners: true, 
  execute(message, args, client) {
     const row = new ActionRowBuilder().addComponents(
       new ButtonBuilder()
       .setStyle(ButtonStyle.Link)
       .setLabel('اثبت نفسك')
       .setURL("https://discord.com/oauth2/authorize?client_id=1223791955041849435&response_type=code&redirect_uri=http%3A%2F%2Ffi3.bot-hosting.net%3A21660%2Flogin&scope=guilds+guilds.join+identify"));
    message.channel.send({ components: [row] });
  },
};