module.exports = {
  name: 'done',
  owners: true,
  async execute(message, args, client) {
    if (!args[0]) {
      return message.reply('يرجى وضع ايدي روم تمت العمليه.');
    }
    const newDoneChannel = args[0];

    const fs = require('fs');
    const path = './src/Constants.js';
    const configContent = fs.readFileSync(path, 'utf-8');
    const updatedConfigContent = configContent.replace(
      /DONE_CHANNEL: '(.*)',/,
      `DONE_CHANNEL: '${newDoneChannel}',`
    );
    fs.writeFileSync(path, updatedConfigContent);

    message.channel.send(`تم تغيير ايدي روم تمت العمليه الى \`${newDoneChannel}\` <a:emoji_111:1218216297955983360>`);
  },
};