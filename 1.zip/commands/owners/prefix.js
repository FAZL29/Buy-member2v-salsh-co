module.exports = {
  name: 'prefix',
  owners: true,
  async execute(message, args, client) {
    if (!args[0]) {
      return message.reply('Please provide a new prefix.');
    }
    const newPrefix = args[0];

    const fs = require('fs');
    const path = './src/Constants.js';
    const configContent = fs.readFileSync(path, 'utf-8');
    const updatedConfigContent = configContent.replace(
      /PREFIX: '(.*)',/,
      `PREFIX: '${newPrefix}',`
    );
    fs.writeFileSync(path, updatedConfigContent);

    message.channel.send(`تم تغيير البريفيكس الى \`${newPrefix}\` <:A4M_setting:1203242437921869864>`);
  },
};