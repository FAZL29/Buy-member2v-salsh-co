module.exports = {

    name: 'bio',

    owners: true,

    async execute(message, args, client) {

        const newBio = args.join(' '); // Joining all arguments to form the bio

        // Check if a bio is provided

        if (!newBio) {

            return message.reply('Please provide a new bio.');

        }

        try {

            // Set the bot's bio

            await client.user.setActivity(newBio);

            message.reply(`Bot bio successfully updated to: ${newBio}`);

        } catch (error) {

            console.error('Error updating bot bio:', error);

            message.reply('An error occurred while updating the bot bio.');

        }

    }

};

