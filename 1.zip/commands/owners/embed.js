const { EmbedBuilder } = require('discord.js');

module.exports = {

    name: 'embed',
owners: true,
    description: 'Send a message with embed',

    execute(message, args) {

        // Check if there's any content provided for the embed

        if (!args.length) {

            return message.reply('Please provide some content for the embed.');

        }

        // Combine all arguments into a single string

        const content = args.join(' ');

        // Create a new embed

        const embed = new EmbedBuilder()

            .setColor('#0099ff')

            .setDescription(content)

            .setTimestamp();

        // Send the embed

        message.channel.send({ embeds: [embed] })

            .then(() => {

                console.log('Embed sent successfully.');

            })

            .catch(error => {

                console.error('Error sending embed:', error);

                message.reply('There was an error sending the embed.');

            });

    },

};

