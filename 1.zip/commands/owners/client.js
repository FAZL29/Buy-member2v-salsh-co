module.exports = {
  name: 'client',
  owners: true,
  async execute(message, args, client) {
    if (!args[0]) {
      return message.reply('يرجى وضع ايدي رول العميل.');
    }
    const newClientsRole = args[0];

    const fs = require('fs');
    const path = './src/Constants.js';
    const configContent = fs.readFileSync(path, 'utf-8');
    const updatedConfigContent = configContent.replace(
      /CLIENTS_ROLE: '(.*)',/,
      `CLIENTS_ROLE: '${newClientsRole}',`
    );
    fs.writeFileSync(path, updatedConfigContent);

    message.channel.send(`تم تغيير ايدي رول العميل الى \`${newClientsRole}\` <:A4M_setting:1203242437921869864>`);
  },
};