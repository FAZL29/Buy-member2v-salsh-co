module.exports = {
  name: 'mozaa',
  owners: true,
  async execute(message, args, client) {
    if (!args[0]) {
      return message.reply('يرجى وضع ايدي رول الموزع.');
    }
    const newMozaaRole = args[0];

    const fs = require('fs');
    const path = './src/Constants.js';
    const configContent = fs.readFileSync(path, 'utf-8');
    const updatedConfigContent = configContent.replace(
      /MOZAA_ROLE: '(.*)',/,
      `MOZAA_ROLE: '${newMozaaRole}',`
    );
    fs.writeFileSync(path, updatedConfigContent);

    message.channel.send(`تم تغيير ايدي رول الموزع الى \`${newMozaaRole}\` <a:emoji_111:1218216297955983360>`);
  },
};