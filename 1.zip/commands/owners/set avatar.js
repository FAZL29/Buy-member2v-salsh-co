module.exports = {
  name: 'setavatar',
  owners: true,
  async execute(message, args, client) {

    const newAvatarURL = args[0];

    try {

      await client.user.setAvatar(newAvatarURL);

      message.reply('تم تغيير صورة البوت بنجاح.');

    } catch (error) {

      console.error('Error changing bot avatar:', error);

      message.reply('حدث خطأ أثناء تغيير صورة البوت.');
        }
      }
    }