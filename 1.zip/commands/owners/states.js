module.exports = {

  name: 'states',

  owners: true,

  async execute(message, args, client) {
      
    const newStatus = args[0]; // Assuming the status is the first argument

    // Check if the provided status is valid

    const validStatuses = ['online', 'idle', 'dnd', 'invisible'];

    if (!validStatuses.includes(newStatus)) {

        return message.reply('Invalid status! Please provide one of the following: online, idle, dnd, invisible');

    }

    try {

        await client.user.setStatus(newStatus);

        message.reply(`تم تغيير حالة البوت بنجاح إلى ${newStatus}.`);

    } catch (error) {

        console.error('Error changing bot status:', error);

        message.reply('حدث خطأ أثناء تغيير حالة البوت.');
        
}   
  }
    };