module.exports = {
  name: 'setname',
  owners: true,
  async execute(message, args, client) {

    const newName = args.join(' ');

    try {

      await client.user.setUsername(newName);

      message.reply(`تم تغيير اسم البوت إلى ${newName}`);

    } catch (error) {

      console.error('Error changing bot name:', error);

      message.reply('حدث خطأ أثناء تغيير اسم البوت.');

    }
      }
    }