module.exports = {
  name: 'limite',
  owners: true,
  async execute(message, args, client) {
    if (!args[0]) {
      return message.reply('يرجي وضع كم اقل كميه للشراء');
    }
    const newMIN_MEMBERS = args[0];

    const fs = require('fs');
    const path = './src/Constants.js';
    const configContent = fs.readFileSync(path, 'utf-8');
    
    const updatedConfigContent = configContent.replace(
      /MIN_MEMBERS: \d+,/,
      `MIN_MEMBERS: ${newMIN_MEMBERS},`
    );
    
    fs.writeFileSync(path, updatedConfigContent);

    message.channel.send(`\`\`\`javascript\n${updatedConfigContent}\n\`\`\``);
    const emoji = `<:A4M_setting:1203242437921869864>`;
    message.react(emoji);
  },
};