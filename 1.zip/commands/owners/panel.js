const { EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');

const bannerData = {

    imageUrl: 'https://cdn.discordapp.com/attachments/1220152653951270984/1221497779965137060/20240324_110551.jpg?ex=6612cb75&is=66005675&hm=6ecf7f2215900bbb3dd6d8f00c9cb4088dc17cdba8717a77040378082949caf8&',

};

module.exports = {

    name: 'panel',

    owners: true,

    execute(message, args, client) {

        const subCommand = args[0];

        if (subCommand === 'img') {

            const imageUrl = args[1];

            if (!imageUrl) {

                return message.reply('يرجى توفير رابط الصورة.');

            }

            bannerData.imageUrl = imageUrl;

            return message.reply('تم تحديث الصورة بنجاح !!!');

        } else {

           const embed = new EmbedBuilder()

        .setTitle('Members Panel')

        .setTimestamp();

      if (bannerData.imageUrl) {

        embed.setImage(bannerData.imageUrl);

      }

      const row = new ActionRowBuilder().addComponents(

        new ButtonBuilder() 

          .setCustomId('buy-balance')
          .setEmoji('<a:wmoney:976894352594976778>')

          .setLabel('شراء رصيد')

          .setStyle(ButtonStyle.Secondary),

        new ButtonBuilder() 

          .setCustomId('withdraw-m-balance')

          .setEmoji('<:members:995698321127649300>')

          .setLabel('شراء اعضاء')

          .setStyle(ButtonStyle.Secondary),

        new ButtonBuilder() 

          .setCustomId('how-to-buy')
          
.setEmoji('<:discotoolsxyzicon25:1213118952792789022>')
          
  .setLabel('كيفيه الشراء')
          .setStyle(ButtonStyle.Primary),    
          
        new ButtonBuilder() 

          .setURL('https://discord.com/oauth2/authorize?client_id=1213581772340592641&permissions=8&response_type=code&redirect_uri=http%3A%2F%2Ffi3.bot-hosting.net%3A21660%2Flogin&scope=guilds.join+guilds+identify+bot')

          .setLabel('إدخال البوت')

          .setStyle(ButtonStyle.Link)

      );

      message.channel.send({ embeds: [embed], components: [row] });

      message.delete();     
            
   }
  },
}