const { EmbedBuilder } = require('discord.js');

module.exports = {

  name: 'spin-panel',

  description: 'Display the spin command panel.',

  async execute(message, args) {

    const embed = new EmbedBuilder()

      .setTitle('Spin Command Panel')

      .setDescription('React with 🔄 to spin the wheel. React with 💸 to initiate a credit transfer.');

    // Send the panel message and store the message object

    const panelBuilder = await message.channel.send(embed);

    // Add reactions to the panel message

    await panelBuilder.react('🔄');

    await panelBuilder.react('💸');

    // Create a reaction collector to listen for reactions on the panel message

    const filter = (reaction, user) => ['🔄', '💸'].includes(reaction.emoji.name) && user.id === message.author.id;

    const collector = panelBuilder.createReactionCollector(filter, { max: 1, time: 60000 });

    // When a reaction is collected

    collector.on('collect', async (reaction, user) => {

      // Check which reaction was collected

      if (reaction.emoji.name === '🔄') {

        // Execute the spin command

        const spinCommand = message.client.commands.get('spin');

        if (spinCommand) {

          spinCommand.execute(message);

        }

      } else if (reaction.emoji.name === '💸') {

        // Execute the transfer command

        const transferCommand = message.client.commands.get('transfer');

        if (transferCommand) {

          transferCommand.execute(message, ['recipientId', 'amount']); // Pass arguments if needed

        }

      }

    });

    // Handle collector end event (e.g., time runs out)

    collector.on('end', collected => {

      if (collected.size === 0) {

        message.channel.send('Spin command panel expired.');

      }

    });

  },

};

