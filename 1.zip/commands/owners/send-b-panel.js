const { EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js'); 

module.exports = {
  name: 'send-b-panel',
  owners: true,
  execute(message, args, client) {
    const embed = new EmbedBuilder()
      .setTitle('شراء رصيد')
      .setColor('#001fff') 
      .setDescription('**يمكنك شراء رصيد عن طريق الضغط على الزر**')
      .setImage('https://cdn.discordapp.com/attachments/1220152653951270984/1221497779965137060/20240324_110551.jpg?ex=6612cb75&is=66005675&hm=6ecf7f2215900bbb3dd6d8f00c9cb4088dc17cdba8717a77040378082949caf8&')  
      .setTimestamp();
    
    const row = new ActionRowBuilder().addComponents(
      new ButtonBuilder() 
      .setStyle(ButtonStyle.Secondary)
      .setCustomId('buy-balance')
      .setEmoji('<:pp393:1028740537215365150>')
      .setLabel('شراء رصيد'));
    
    message.channel.send({ embeds: [embed], components: [row] });
    message.delete();
  },
};
